# -*- coding: utf-8 -*-
r"""
199/config.py
NeoLegal Production Platform - Production Manager configuration
"""

from pathlib import Path

BASE_DIR = Path(r"C:\Users\MSI\Desktop\kik_proje")
PY_DIR = BASE_DIR / ".py"
STATE_DIR = BASE_DIR / "production_state"
REPORT_DIR = BASE_DIR / "raporlar"
REGISTRY_DIR = STATE_DIR / "service_registry"
JOB_QUEUE_DIR = STATE_DIR / "job_queue"

SERVICE_REGISTRY_FILE = REGISTRY_DIR / "199_service_registry.json"
QUEUE_FILE = JOB_QUEUE_DIR / "198_job_queue_state.json"
WORKER_FILE = JOB_QUEUE_DIR / "198_worker_state.json"

MIN_DISK_GB = 50

CORE_SERVICES = {
    "181": "Production Controller",
    "192": "Resume Engine",
    "193": "Smart Resume Validation",
    "194": "Production Guardian",
    "195": "Runtime Monitor",
}

CERTIFICATION_SERVICES = {
    "196": "Production Certification Suite",
    "196B": "Dynamic Certification",
}

RECOVERY_SERVICES = {
    "197": "Recovery Manager",
}

ORCHESTRATION_SERVICES = {
    "198": "Queue / Worker / Controlled Execution",
    "199": "Production Manager",
}

PIPELINE_SERVICES = {
    "168": "Production",
    "188": "Auto Cleaner",
    "172": "AI Quality",
    "175": "Coverage",
    "176": "Priority",
    "177": "Legal Accuracy",
    "185": "Self Healing",
    "178": "Merge",
    "179": "Optimize",
    "180": "Complexity",
    "169": "DB Import",
    "170": "Export",
    "173": "Acceptance",
    "182": "Drift",
    "183": "Sampling",
    "184": "Dashboard",
    "190": "Supervisor",
}

ALL_SERVICE_CATEGORIES = {
    "core": CORE_SERVICES,
    "certification": CERTIFICATION_SERVICES,
    "recovery": RECOVERY_SERVICES,
    "orchestration": ORCHESTRATION_SERVICES,
    "pipeline": PIPELINE_SERVICES,
}
