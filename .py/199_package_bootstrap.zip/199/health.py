# -*- coding: utf-8 -*-
r"""
199/health.py
Platform Health component.
"""

import sqlite3
from config import BASE_DIR, STATE_DIR, REPORT_DIR, SERVICE_REGISTRY_FILE, QUEUE_FILE, WORKER_FILE, MIN_DISK_GB
from utils import now_stamp, now_text, ensure_dirs, disk_free_gb, safe_json, latest_file, safe_read, write_json


def discover_db():
    candidates = []
    for p in BASE_DIR.rglob("*.db"):
        if "kik" in p.name.lower():
            candidates.append(p)
    candidates = list(set(candidates))
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    if not candidates:
        return {"status": "FAIL", "path": None, "table": None, "count": 0, "message": "KİK DB bulunamadı."}

    db_path = candidates[0]
    try:
        conn = sqlite3.connect(str(db_path))
        cur = conn.cursor()
        tables = [x[0] for x in cur.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        table = None
        for t in ("hukuki_kartlar", "kararlar", "kik_kararlari", "cards", "legal_cards"):
            if t in tables:
                table = t
                break
        if not table and tables:
            table = tables[0]
        if not table:
            conn.close()
            return {"status": "FAIL", "path": str(db_path), "table": None, "count": 0, "message": "DB var ama tablo yok."}
        count = cur.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        conn.close()
        return {"status": "PASS" if count > 0 else "WARNING", "path": str(db_path), "table": table, "count": count, "message": f"DB OK: {count}"}
    except Exception as e:
        return {"status": "FAIL", "path": str(db_path), "table": None, "count": 0, "message": f"DB okunamadı: {e}"}


def registry_health():
    reg = safe_json(SERVICE_REGISTRY_FILE)
    if not reg:
        return {"status": "FAIL", "found": 0, "total": 0, "message": "Service registry yok veya okunamadı."}
    flat = reg.get("flat_services", {})
    total = len(flat)
    found = sum(1 for item in flat.values() if item.get("status") == "FOUND")
    status = "PASS" if total > 0 and found == total else ("WARNING" if found else "FAIL")
    return {"status": status, "found": found, "total": total, "message": f"{found}/{total} servis bulundu."}


def queue_health():
    q = safe_json(QUEUE_FILE)
    if not q:
        return {"status": "WARNING", "message": "Queue yok veya okunamadı.", "total": 0}
    jobs = q.get("jobs", [])
    counts = {}
    for job in jobs:
        st = job.get("status", "UNKNOWN")
        counts[st] = counts.get(st, 0) + 1
    status = "PASS" if len(jobs) > 0 and counts.get("FAILED", 0) == 0 else "WARNING"
    return {"status": status, "total": len(jobs), "waiting": counts.get("WAITING", 0), "running": counts.get("RUNNING", 0), "finished": counts.get("FINISHED", 0), "failed": counts.get("FAILED", 0), "retry": counts.get("RETRY", 0), "message": f"Queue total={len(jobs)}"}


def worker_health():
    w = safe_json(WORKER_FILE)
    if not w:
        return {"status": "WARNING", "message": "Worker yok veya okunamadı.", "total": 0}
    workers = w.get("workers", [])
    counts = {}
    for worker in workers:
        st = worker.get("status", "UNKNOWN")
        counts[st] = counts.get(st, 0) + 1
    status = "PASS" if workers and counts.get("UNKNOWN", 0) == 0 else "WARNING"
    return {"status": status, "total": len(workers), "idle": counts.get("IDLE", 0), "running": counts.get("RUNNING", 0), "disabled": counts.get("DISABLED", 0), "message": f"Workers total={len(workers)}"}


def latest_health(pattern, tokens, label):
    f = latest_file(STATE_DIR, pattern)
    if not f:
        return {"status": "WARNING", "file": None, "message": f"{label} state bulunamadı."}
    text = safe_read(f).lower()
    ok = any(t.lower() in text for t in tokens)
    return {"status": "PASS" if ok else "WARNING", "file": str(f), "message": f"{label}: {'OK' if ok else 'review'}"}


def evaluate(parts):
    weights = {"registry":20, "db":25, "disk":15, "queue":10, "worker":10, "recovery":10, "dynamic":5, "orchestrator":5}
    score = 100
    errors = []
    warnings = []
    for key, weight in weights.items():
        st = parts.get(key, {}).get("status")
        msg = parts.get(key, {}).get("message")
        if st == "FAIL":
            score -= weight
            errors.append(f"{key} FAIL: {msg}")
        elif st == "WARNING":
            score -= max(2, weight // 2)
            warnings.append(f"{key} WARNING: {msg}")
    score = max(0, min(100, score))
    decision = "PLATFORM BLOCKED" if errors else ("PLATFORM READY" if score >= 90 else "PLATFORM REVIEW")
    return {"score": score, "decision": decision, "errors": errors, "warnings": warnings}


def run():
    ensure_dirs(STATE_DIR, REPORT_DIR)
    ts = now_stamp()
    free = disk_free_gb(BASE_DIR)
    parts = {
        "registry": registry_health(),
        "db": discover_db(),
        "disk": {"status": "PASS" if free >= MIN_DISK_GB else "FAIL", "free_gb": free, "message": f"Disk free {free} GB"},
        "queue": queue_health(),
        "worker": worker_health(),
        "recovery": latest_health("197_v4_recovery_manager_state_*.json", ["recovery clean", '"score": 100'], "Recovery"),
        "dynamic": latest_health("196B_v2_controlled_dynamic_state_*.json", ["dynamic certified"], "Dynamic Certification"),
        "orchestrator": latest_health("199_v3_orchestrator_state_*.json", ["orchestrator certified"], "Orchestrator"),
    }
    result = evaluate(parts)
    payload = {"module": "199 Package Platform Health", "created_at": now_text(), "health": parts, "result": result}
    state_path = STATE_DIR / f"199_pkg_health_state_{ts}.json"
    report_path = REPORT_DIR / f"199_pkg_health_raporu_{ts}.txt"
    write_json(state_path, payload)

    lines = [
        "=" * 80,
        "199 PACKAGE - PLATFORM HEALTH",
        "=" * 80,
        f"Score    : {result['score']} / 100",
        f"Decision : {result['decision']}",
        f"Errors   : {len(result['errors'])}",
        f"Warnings : {len(result['warnings'])}",
        f"DB Count : {parts['db'].get('count')}",
        f"Queue    : W={parts['queue'].get('waiting')} R={parts['queue'].get('running')} F={parts['queue'].get('finished')} Fail={parts['queue'].get('failed')}",
        f"Workers  : idle={parts['worker'].get('idle')} running={parts['worker'].get('running')} total={parts['worker'].get('total')}",
        "",
        "Dosyalar:",
        str(state_path),
        str(report_path),
    ]
    report_path.write_text("\n".join(lines), encoding="utf-8")
    return {"health": parts, "result": result, "paths": {"state": str(state_path), "report": str(report_path)}}
