# 199 Production Manager Package

Bu klasör, NeoLegal Production Platform içindeki merkezi platform yönetim katmanıdır.

Amaç:
- Service Registry
- Platform Health
- Orchestrator
- Production Manager
- Platform Certification

bileşenlerini tek pakette toplamak.

Bu ilk sürüm mevcut çalışan 199_v1, 199_v2, 199_v3 ve 199_v4 dosyalarını bozmaz.
Paket mimarisi geçiş katmanı olarak tasarlanmıştır.
