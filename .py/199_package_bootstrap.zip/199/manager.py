# -*- coding: utf-8 -*-
r"""
199/manager.py
Main package entrypoint.
"""

import argparse
from registry import run as run_registry
from health import run as run_health


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--registry", action="store_true", help="Service registry çalıştırır.")
    parser.add_argument("--health", action="store_true", help="Platform health çalıştırır.")
    parser.add_argument("--all", action="store_true", help="Registry + Health birlikte çalıştırır.")
    args = parser.parse_args()

    if args.all or (not args.registry and not args.health):
        reg = run_registry()
        health = run_health()
        print("=" * 80)
        print("199 PACKAGE MANAGER TAMAMLANDI")
        print("=" * 80)
        print(f"Registry : {reg['result']['decision']} ({reg['result']['score']}/100)")
        print(f"Health   : {health['result']['decision']} ({health['result']['score']}/100)")
        print("")
        print("Dosyalar:")
        print(reg["paths"]["report"])
        print(health["paths"]["report"])
        return

    if args.registry:
        reg = run_registry()
        print("=" * 80)
        print("199 PACKAGE REGISTRY TAMAMLANDI")
        print("=" * 80)
        print(f"Decision : {reg['result']['decision']}")
        print(f"Score    : {reg['result']['score']} / 100")
        print(reg["paths"]["report"])

    if args.health:
        health = run_health()
        print("=" * 80)
        print("199 PACKAGE HEALTH TAMAMLANDI")
        print("=" * 80)
        print(f"Decision : {health['result']['decision']}")
        print(f"Score    : {health['result']['score']} / 100")
        print(health["paths"]["report"])


if __name__ == "__main__":
    main()
