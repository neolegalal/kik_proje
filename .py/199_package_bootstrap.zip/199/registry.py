# -*- coding: utf-8 -*-
r"""
199/registry.py
Service Registry component.
"""

from config import PY_DIR, STATE_DIR, REPORT_DIR, REGISTRY_DIR, SERVICE_REGISTRY_FILE, ALL_SERVICE_CATEGORIES
from utils import now_stamp, now_text, ensure_dirs, disk_free_gb, find_scripts, file_info, write_json

def build_registry():
    registry = {
        "module": "199 Package Service Registry",
        "created_at": now_text(),
        "py_dir": str(PY_DIR),
        "disk_free_gb": disk_free_gb(PY_DIR.parent),
        "categories": {},
        "flat_services": {},
    }

    for category, services in ALL_SERVICE_CATEGORIES.items():
        registry["categories"][category] = {}
        for prefix, label in services.items():
            scripts = find_scripts(PY_DIR, prefix)
            primary = scripts[0] if scripts else None
            item = {
                "prefix": prefix,
                "label": label,
                "category": category,
                "status": "FOUND" if primary else "MISSING",
                "primary_script": file_info(primary) if primary else None,
                "script_count": len(scripts),
                "all_scripts": [file_info(p) for p in scripts[:20]],
            }
            registry["categories"][category][prefix] = item
            registry["flat_services"][prefix] = item
    return registry


def evaluate_registry(registry):
    score = 100
    errors = []
    warnings = []

    for prefix, item in registry["categories"].get("core", {}).items():
        if item["status"] != "FOUND":
            score -= 10
            errors.append(f"Core service missing: {prefix} {item['label']}")

    for prefix, item in registry["categories"].get("pipeline", {}).items():
        if item["status"] != "FOUND":
            score -= 3
            warnings.append(f"Pipeline service missing: {prefix} {item['label']}")

    for cat in ["certification", "recovery", "orchestration"]:
        for prefix, item in registry["categories"].get(cat, {}).items():
            if item["status"] != "FOUND":
                score -= 5
                warnings.append(f"{cat} service missing: {prefix} {item['label']}")

    score = max(0, min(100, score))
    decision = "REGISTRY READY" if not errors and score >= 95 else ("REGISTRY NOT READY" if errors else "REGISTRY REVIEW")
    return {"score": score, "decision": decision, "errors": errors, "warnings": warnings}


def run():
    ensure_dirs(STATE_DIR, REPORT_DIR, REGISTRY_DIR)
    ts = now_stamp()
    registry = build_registry()
    result = evaluate_registry(registry)

    registry_path = SERVICE_REGISTRY_FILE
    state_path = STATE_DIR / f"199_pkg_registry_state_{ts}.json"
    report_path = REPORT_DIR / f"199_pkg_registry_raporu_{ts}.txt"

    write_json(registry_path, registry)
    write_json(state_path, {"registry": registry, "result": result})

    found = sum(1 for item in registry["flat_services"].values() if item["status"] == "FOUND")
    total = len(registry["flat_services"])

    lines = [
        "=" * 80,
        "199 PACKAGE - SERVICE REGISTRY",
        "=" * 80,
        f"Score    : {result['score']} / 100",
        f"Decision : {result['decision']}",
        f"Found    : {found} / {total}",
        f"Errors   : {len(result['errors'])}",
        f"Warnings : {len(result['warnings'])}",
        "",
        "Dosyalar:",
        str(registry_path),
        str(state_path),
        str(report_path),
    ]
    report_path.write_text("\n".join(lines), encoding="utf-8")
    return {"registry": registry, "result": result, "paths": {"registry": str(registry_path), "state": str(state_path), "report": str(report_path)}}
