# -*- coding: utf-8 -*-
r"""
199_Package_Manager.py

199 paket mimarisine geçiş için köprü script.
Bu dosya .py klasörünün köküne konur.
"""

import sys
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent / "199"
sys.path.insert(0, str(PACKAGE_DIR))

from manager import main

if __name__ == "__main__":
    main()
